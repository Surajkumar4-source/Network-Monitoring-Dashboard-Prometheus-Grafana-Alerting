---
title: Panel options
comments: |
  This file is used in all visualizations pages
---

In the **Panel options** section of the panel editor pane, set basic options like panel title and description, as well as panel links. To learn more, refer to [Configure panel options](../../configure-panel-options/).
