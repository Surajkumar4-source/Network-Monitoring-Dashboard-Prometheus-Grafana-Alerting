---
title: Stack series link
---

## Axis

For full instructions, refer to [Change axis display]({{< relref "../../visualizations/time-series/change-axis-display/" >}}).
