---
title: Configuration options intro text
comments: |
  This file is used in the following in all visualizations except: alert list, annotiations list, logs, news, text
---

The following section describes the configuration options available in the panel editor pane for this visualization. These options are, as much as possible, ordered as they appear in Grafana.
