---
labels:
  products:
    - enterprise
    - oss
title: Select home dashboard list
---

1. In the **Home Dashboard** field, select the dashboard that you want to use for your home dashboard. Options include all starred dashboards.
1. Click **Save**.
