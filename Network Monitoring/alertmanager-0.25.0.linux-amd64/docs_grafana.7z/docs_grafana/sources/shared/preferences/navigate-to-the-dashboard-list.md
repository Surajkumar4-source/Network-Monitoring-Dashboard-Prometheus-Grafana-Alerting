---
labels:
  products:
    - enterprise
    - oss
title: Navigate to the dashboard list
---

1. Navigate to the dashboard you want to set as the home dashboard.
1. Click the star next to the dashboard title to mark the dashboard as a favorite if it is not already.
