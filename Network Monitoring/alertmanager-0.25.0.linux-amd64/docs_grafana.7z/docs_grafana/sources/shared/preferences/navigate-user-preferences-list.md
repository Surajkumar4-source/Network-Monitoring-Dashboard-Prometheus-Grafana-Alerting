---
labels:
  products:
    - enterprise
    - oss
title: Navigate to user preferences list
---

1. On the left menu, hover your cursor over your avatar and then click **Preferences**.
