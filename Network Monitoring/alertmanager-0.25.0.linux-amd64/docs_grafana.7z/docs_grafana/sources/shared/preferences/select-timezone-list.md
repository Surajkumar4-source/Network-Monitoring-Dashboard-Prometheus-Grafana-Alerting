---
labels:
  products:
    - enterprise
    - oss
title: Select home dashboard list
---

1. Click to select an option in the **Timezone** list. **Default** is either the browser local timezone or the timezone selected at a higher level.
1. Click **Save**.
