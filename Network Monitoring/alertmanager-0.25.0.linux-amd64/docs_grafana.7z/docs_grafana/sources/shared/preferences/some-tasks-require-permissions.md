---
labels:
  products:
    - enterprise
    - oss
title: Some tasks require permissions
---

Some tasks require certain permissions. For more information about roles, refer to [About users and permission]({{< relref "../../administration/manage-users-and-permissions/about-users-and-permissions/" >}}).
