---
labels:
  products:
    - enterprise
    - oss
title: Click Org preferences
---

1. Hover your cursor over the **Configuration** (gear) icon.
1. Click **Preferences**.
