---
labels:
  products:
    - enterprise
    - oss
title: Select the UI theme
---

1. In the Preferences section, select the **UI theme**.
1. Click **Save**.
