---
labels:
  products:
    - enterprise
    - oss
title: View user list
---

1. Hover your cursor over the **Server Admin** (shield) icon until a menu appears.
1. Click **Orgs**.
