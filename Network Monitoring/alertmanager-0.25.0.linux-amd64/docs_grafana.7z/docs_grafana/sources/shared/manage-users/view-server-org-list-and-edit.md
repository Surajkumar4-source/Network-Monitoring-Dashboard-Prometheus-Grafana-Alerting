---
labels:
  products:
    - enterprise
    - oss
title: View org list as server admin
---

{{< docs/list >}}
{{< docs/shared lookup="manage-users/view-server-org-list.md" source="grafana" version="<GRAFANA VERSION>" >}}

1. Click the name of the organization that you want to edit.

{{< /docs/list >}}
