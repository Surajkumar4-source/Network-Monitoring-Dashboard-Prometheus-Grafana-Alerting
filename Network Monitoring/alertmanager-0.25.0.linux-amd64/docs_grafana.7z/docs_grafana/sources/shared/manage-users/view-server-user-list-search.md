---
labels:
  products:
    - enterprise
    - oss
title: View user list and search - list format
---

{{< docs/list >}}
{{< docs/shared lookup="manage-users/view-server-user-list.md" source="grafana" version="<GRAFANA VERSION>" >}}

1. Click the user account that you want to edit. If necessary, use the search field to find the account.

{{< /docs/list >}}
