---
labels:
  products:
    - enterprise
    - oss
title: View team list
---

1. Hover your cursor over the **Configuration** (gear) icon in the side menu.
1. Click **Teams**. Grafana displays the team list.
