---
labels:
  products:
    - enterprise
    - oss
title: View user list
---

1. Hover your cursor over the **Server Admin** (shield) icon until a menu appears.
1. Click **Users**.
1. Click the user account that you want to edit. If necessary, use the search field to find the account.
