---
labels:
  products:
    - enterprise
    - oss
title: Panel links intro
---

Each panel can have its own set of links that are shown in top left of a panel after the panel title. You can link to any available URL, including dashboards, panels, or external sites. You can even control the time range to ensure the user is zoomed in on the right data in Grafana.
