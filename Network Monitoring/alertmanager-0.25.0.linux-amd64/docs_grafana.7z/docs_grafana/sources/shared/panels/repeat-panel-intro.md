---
labels:
  products:
    - enterprise
    - oss
title: Repeat panel intro
---

Grafana lets you create dynamic dashboards using _template variables_. All variables in your queries expand to the current value of the variable before the query is sent to the database. Variables let you reuse a single dashboard for all your services.
