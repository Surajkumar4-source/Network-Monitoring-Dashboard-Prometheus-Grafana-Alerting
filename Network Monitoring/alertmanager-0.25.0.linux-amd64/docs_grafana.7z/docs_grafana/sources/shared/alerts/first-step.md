---
labels:
  products:
    - enterprise
    - oss
title: TBD
---

## TBD

Use the instructions in [Getting started with Grafana]({{< relref "../../getting-started/getting-started/" >}}) to:

- Install Grafana.
- Log in to Grafana.
- Create your first dashboard.
