---
labels:
  products:
    - enterprise
    - oss
title: Grafana Cloud
---

## Grafana Cloud

Grafana Cloud is a highly available, fast, fully managed OpenSaaS logging and metrics platform. It is everything you love about Grafana, but Grafana Labs hosts it for you and handles all the headaches.
