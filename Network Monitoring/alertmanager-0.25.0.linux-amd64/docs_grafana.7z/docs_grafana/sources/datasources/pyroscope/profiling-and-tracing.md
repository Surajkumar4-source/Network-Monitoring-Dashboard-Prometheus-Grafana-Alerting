---
title: How profiling and tracing work together
menuTitle: How profiling and tracing work together
description: Learn about how profiling and tracing work together.
weight: 250
keywords:
  - pyroscope data source
  - continuous profiling
  - tracing
---

# How profiling and tracing work together

[//]: # 'Shared content for Trace to profiles in the Pyroscope data source'

{{< docs/shared source="grafana" lookup="datasources/pyroscope-profile-tracing-intro.md" version="<GRAFANA_VERSION>" >}}
